$(function(){
		$(".st0").css({transform:"rotate(360deg)"});


		$("a","aside ul li").eq(0).addClass("view");	
		$("a + span","aside ul li").eq(0).show();				
		var winHeight = $(window).height(); // 현재 페이지의 높이 값;

		$(window).scroll(function(){
			var scrollPos = $(this).scrollTop(); 
		    if (scrollPos >= winHeight * 4) {
		    	aside(4);
			} else if (scrollPos >= winHeight * 3) {
		    	aside(3);		
			} else if (scrollPos >= winHeight * 2) {
		    	aside(2);						
			} else if(scrollPos >= winHeight) {
		    	aside(1);							
			} else if(scrollPos >= 0) {
		    	aside(0);							
			}
		});

		function aside(num) {
			$("a","aside ul li").removeClass("view").eq(num).addClass("view");				
			$("a + span","aside ul li").hide().eq(num).show();				
		}

		$("aside ul li").hover(function(){
			$("span", this).show();
		},function(){
			$("span",this).hide();
		}).click(function(){
			var chkIndex = $(this).index();
			$("html,body").animate({scrollTop:winHeight*chkIndex});
			return false;
		});


		$(window).resize(function(){
			winHeight = $(window).height(); // 현재 페이지의 높이 값;		
		});

		$("#page03 section ul li").click(function(){
			var chkIndex = $(this).index();
			var chgName = $("a", this).attr("href");
			var chgTxt = $("h6",this).html();

			$("#modal #view img").attr("src",chgName);
			$("#modal p").html(chgTxt);
			$("#modal").fadeIn();
			return false;
		});

		$("#modal button#btnClose").click(function(){
			$("#modal").fadeOut();
		});


		var curPage = 0;

		$("#modal button#btnRight").click(function(){
			curPage = (curPage + 1) % 12; 
			chgTxt = $("h6", "#page03 section ul li").eq(curPage).html(); // 다음 글자 불러 오기
			$("#modal p").html(chgTxt);

			chgName = $("a", "#page03 section ul li").eq(curPage).attr("href"); 
			$("#modal #view img").attr("src",chgName); // 다음 이미지 불러 오기			

		});	

		$("#modal button#btnLeft").click(function(){
			curPage = (curPage - 1) % 12;
			chgTxt = $("h6", "#page03 section ul li").eq(curPage).html(); // 다음 글자 불러 오기
			$("#modal p").html(chgTxt);

			chgName = $("a", "#page03 section ul li").eq(curPage).attr("href"); 
			$("#modal #view img").attr("src",chgName); // 다음 이미지 불러 오기				
		});	


		$('.wrap').mousewheel(function(e,delta){
			currentTop = $(this).offset().top;

			if(delta > 0){
				$("html,body").stop().animate({scrollTop:currentTop-winHeight});
				return false;
			} else {
				$("html,body").stop().animate({scrollTop:currentTop+winHeight});				
				return false;
			}
		});		

		$("#page01").on("mousemove",function(e){
			w = $(this).width(); 
			h = $(this).height();			

			x = 30 * Math.ceil(e.pageX / w * 100 ) / 100;
			y = 30 * Math.ceil(e.pageY / h * 100 ) / 100;

			$("#zLayer img").eq(0).css({marginLeft: -x, marginTop: -y});
			$("#zLayer img").eq(1).css({marginLeft: x * 2, marginTop:y * 2});
		});	

		 var slideClick = 0;
		 $("#page04 section button#btnLeft").click(function(){
		 	slideClick++;
		 	if(slideClick < 3) {
		 		$("#page04 section #sliderMask ul").stop().animate({marginLeft:"-=39%"});
		 	} else {
		 		slideClick = 2;
		 	}
		 });


		 $("#page04 section button#btnRight").click(function(){


		 	if(slideClick > 0) {
		 		$("#page04 section #sliderMask ul").stop().animate({marginLeft:"+=39%"});
		 		slideClick--;
		 	}
		 		 	
		 });
	});